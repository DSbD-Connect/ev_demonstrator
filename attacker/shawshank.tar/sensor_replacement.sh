cp ev_sensor ev_sensor_orig
cp ev_sensor_hijack.sh ev_sensor
chmod +x ev_sensor