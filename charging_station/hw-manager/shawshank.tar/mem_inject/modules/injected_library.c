#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <unistd.h>
#include <stdlib.h>
#include <dlfcn.h>


int entry_point() {
    puts("                            ");
    puts("you");
    puts("have been");
    puts("hacked");
    puts("by lib");
    puts("!!!");
    return 0;
}
